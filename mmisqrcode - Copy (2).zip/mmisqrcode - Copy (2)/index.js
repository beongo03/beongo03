var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
const list={};
var port = process.env.PORT || 3000;
app.use(express.static(__dirname + '/public'));
app.listen(8080);



app.get('/', function(req, res){
  res.sendFile(__dirname + '/public/car.html');
});
app.get('/kia', function(req, res){
  res.sendFile(__dirname + '/public/kia.html');
});
app.get('/car', function(req, res){
		var id = req.query.id;
res.sendFile(__dirname + '/public/sorento.html');
});

io.on('connection', function(socket){
	  socket.emit('id',socket.id);

  console.log(socket.id + ' connected');
   // io.emit('connection','user connected');

  socket.on('disconnect', function(){
  console.log(socket.id + ' disconnected');
  io.to(list[socket.id]).emit('refesh', list[socket.id]);
  });
  socket.on('play tvc', function(msg){
	 
      let otherSocket = io.sockets.connected[msg[0]];
      if(!!otherSocket && otherSocket.connected) {
		  io.to(msg[0]).emit('play tvc', msg[1]);
	  } else {
		  socket.emit('client disconnected',0);
	  }
  });
    socket.on('change section', function(msg){
		let otherSocket = io.sockets.connected[msg[0]];
      if(!!otherSocket && otherSocket.connected) {
		      io.to(msg[0]).emit('change section', msg[1]);

	  } else {
		  socket.emit('client disconnected',0);
	  }
  });
   socket.on('mattruoc effect', function(msg){
	    
		let otherSocket = io.sockets.connected[msg[0]];
      if(!!otherSocket && otherSocket.connected) {
		     io.to(msg[0]).emit('mattruoc effect', msg[1]);

	  } else {
		  socket.emit('client disconnected',0);
	  }
 
   
  });
     
   socket.on('refesh', function(msg){

    io.to(msg[0]).emit('refesh', msg[1]);
  });
     socket.on('welcome', function(msg){
	list[socket.id]=	msg[0]; 
    io.to(msg[0]).emit('welcome', msg[1]);
  });
});

http.listen(port, function(){
  console.log('listening on *:3000');
});